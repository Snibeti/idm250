</html> 
<!-- I don't actually have a footer in my styles, might add something later though. -->