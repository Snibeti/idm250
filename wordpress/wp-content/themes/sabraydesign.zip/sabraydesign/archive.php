<?php


get_template_part('templates/template-post-listing');
