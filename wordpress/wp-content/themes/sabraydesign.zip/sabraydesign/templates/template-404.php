<?php get_header(); ?>
<body>
  
    <div id="blue_rectangle_mini"></div>
    <div id="robo"></div>
    <div id="four_dot_grid"></div>
    <div id="line_top"></div>
   
   <p class="four_o_four">404</p>
   <div class="four_text">
   <p>Looks like you’re lost! The page you are looking for could not be found.</p>
   <a href="<?php echo home_url(); ?>" id="four_button" class="button">Back Home</a>
   </div>
</body>
<?php get_footer(); ?>