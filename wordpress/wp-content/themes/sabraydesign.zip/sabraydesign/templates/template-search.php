<?php
/*
Template Name: Search Results
*/
get_header(); ?>

<?php get_footer(); ?>